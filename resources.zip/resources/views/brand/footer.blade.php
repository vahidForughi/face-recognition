<div class="center pt-3">
    <p class="small m-n">
        © Copyright {{date('Y')}}
        <a href="{{ config('app.url') }}" target="_blank">
            {{ config('app.name') }}
        </a>
    </p>
</div>
