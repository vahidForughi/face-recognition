filed: <span {{ $attributes }}>{{ $value }}</span><br/>
